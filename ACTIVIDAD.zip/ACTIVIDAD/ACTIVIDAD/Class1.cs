﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACTIVIDAD
{
    class Class1
    {
        public string Nombre { get; set; }
        public string Cuenta { get; set; } 
        public string Calificación { get; set; } 
        public string Materia { get; set; }


    }
}
